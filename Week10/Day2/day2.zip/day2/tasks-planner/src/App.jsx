import "./App.css";
import Tasks from "./features/tasks/Tasks";
function App() {
  return (
    <>
      <Tasks />
    </>
  );
}

export default App;
