import TaskInput from "./TaskInput";
import TasksList from "./TasksList";
const Tasks = () => {
  return (
    <>
      <h2> Tasks Planner</h2>
      <TaskInput />
      <TasksList />
    </>
  );
};
export default Tasks;
