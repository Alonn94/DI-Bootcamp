import "./App.css";
import Counter from "./features/counter/Counter";
function App() {
  return (
    <>
      <h2>Redux Toolkit</h2>
      <Counter />
    </>
  );
}

export default App;
