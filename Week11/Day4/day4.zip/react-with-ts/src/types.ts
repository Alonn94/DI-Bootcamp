export type HeadingProps = {
  title: string;
  subTitle?: string;
};
