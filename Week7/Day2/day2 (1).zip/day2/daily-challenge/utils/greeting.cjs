const greet = (name) => {
  return `Hello, ${name}`;
};

const hello = () => {
  return "bey";
};

module.exports = {
  greet,
  hello
};
